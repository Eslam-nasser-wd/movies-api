module.exports = {

    'db': 'mongodb://root:94982bf5-85f7-436f-9058-28357aa23e3a@ds135669.mlab.com:35669/movies_api' // mLab
    //'db2': 'mongodb://root:94982bf5-85f7-436f-9058-28357aa23e3a@jello.modulusmongo.net:27017/zy8dinYp' // Xervo
    
}